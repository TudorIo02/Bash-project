#!/bin/bash
i=986
clear
echo "Apasa tasta:"; sleep 2
while [ $i -ne 0 ]
  do
    clear
    echo "1. Deschidere fisier csv"
    echo "2. Modificare nr. livrari al unui angajat in functie de id"
    echo "3. Calculare salarii"
    echo "4. Afisare salarii angajati"
    echo "5. Consultare tabel informatii"
    echo "6. Angajare nou livrator"
    echo "7. Concediere"
    echo "8. Autoconcediere a angajatilor cu <50 livrari"
    echo "9. Sortare in functie de livrari"
    echo "0. Iesire meniu"
    read i
    case $i in
      1) ./opt1.sh; clear;;
      2) ./opt2.sh;;
      3) ./opt3.sh;;
      4) ./opt4.sh;;
      5) ./opt5.sh;;
      6) ./opt6.sh;;
      7) ./opt7.sh;;
      8) ./opt8.sh;;
      9) ./opt9.sh;;
      0) clear; echo "DONE";sleep 2;;
    esac
  done
clear
