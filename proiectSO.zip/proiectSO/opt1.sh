#!/bin/bash
nano date.csv
