#!/bin/bash

clear
read -p "Introdu id-ul angajatului dorit: " id

if grep -q "^$id," date.csv; then
    while true; do
        read -p "Introdu numarul de livrari al angajatului $id: " livrari
        if [[ "$livrari" =~ ^[0-9]+$ ]]; then
            awk -v id="$id" -v livrari="$livrari" 'BEGIN{FS=OFS=","} $1==id{$3=livrari} 1' date.csv > temp.csv
            mv temp.csv date.csv
            echo "Modificare realizata cu succes!"
            break
        else
            echo "Numarul de livrari trebuie sa fie un numar intreg."
        fi
    done
else
    echo "ERROR: id inexistent"
fi

sleep 3; clear
