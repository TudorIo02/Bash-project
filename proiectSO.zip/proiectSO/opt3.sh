#!/bin/bash
clear
awk 'BEGIN{FS=OFS=","} NR>1{$4 = 6000*$3/200} 1' date.csv > temp.csv
mv temp.csv date.csv

cowsay "Procesare..."; sleep 2
clear

echo "Calcul realizat cu succes. Acum fiecare salariu este calculat in functie de nr de livrari."
sleep 5; clear
