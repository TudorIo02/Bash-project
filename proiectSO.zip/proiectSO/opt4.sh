#!/bin/bash
clear
while IFS=',' read  _ arg2 _ arg4 _; do
    echo "$arg2: $arg4"
done < <(tail -n +2 date.csv)
echo "---------------------------------------"
read -p "Apasa enter pentru a te intoarce la meniu" w
