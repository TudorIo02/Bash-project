#!/bin/bash

clear
file="date.csv"

function liniesep() {
    printf "%s\n" "-------------------------------------------------"
}

if [[ -f "$file" ]]; then
    header=$(head -n 1 "$file")

    IFS="," read -ra headers <<< "$header"
    printf "%-3s | %-20s | %-8s | %-7s\n" "${headers[0]}" "${headers[1]}" "${headers[2]}" "${headers[3]}"
    liniesep

    tail -n +2 "$file" | while IFS="," read id nume livrari salariu; do
        printf "%-3s | %-20s | %-8s | %-7s\n" "$id" "$nume" "$livrari" "$salariu"
    done

    liniesep
else
    echo "Fișierul $file nu există."
fi

read -p "Apasa ENTER pt a reveni la meniu!" i
