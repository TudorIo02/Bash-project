#!/bin/bash

clear
idvechi=$(cut -d ',' -f 1 date.csv | tail -n +2 | sort -n | tail -n 1)
idnou=$((idvechi + 1))

function corectare() {
    if [[ "$1" =~ ^[[:alpha:][:space:]]+$ ]]; then
        return 0
    else
        return 1
    fi
}

while true; do
    read -p "Introdu numele angajatului: " nume
    if corectare "$nume"; then
        break
    else
        echo "Numele poate contine doar litere si spatii. Te rog sa introduci numele corect."
    fi
done

echo "$idnou,$nume,200,6000" >> date.csv
echo "Angajare realizata cu succes!"; sleep 3; clear
