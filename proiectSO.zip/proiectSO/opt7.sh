#!/bin/bash

clear
read -p "Introdu ID-ul: " id

if grep -q "^$id," date.csv
  then
    grep -v "^$id," date.csv > temp.csv
    mv temp.csv date.csv
    echo "Angajatul $id a fost concediat!"; sleep 3; clear

else
    echo "ID-ul $id nu exista!"; sleep 3; clear
fi
