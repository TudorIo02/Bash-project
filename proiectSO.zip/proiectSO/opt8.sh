#!/bin/bash

clear
i=0
temp=$(mktemp)

head -n 1 date.csv > "$temp"

while IFS=',' read id nume livrari salariu; do
    if ((livrari < 50)); then
        echo "Angajat $id concediat."
        ((i++))
    else
        echo "$id,$nume,$livrari,$salariu" >> "$temp"
    fi
done < <(tail -n +2 date.csv)

mv "$temp" date.csv

if ((i > 0)); then
    echo "Autoconciediere reusita."
    sleep 2
else
    echo "Niciun livrator concediat."
    sleep 2
fi

