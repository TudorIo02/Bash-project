#!/bin/bash
clear
header=$(head -1 date.csv)

tail -n +2 date.csv | sort -t',' -k3,3nr > sortat.csv

echo "$header" > temp.csv
cat sortat.csv >> temp.csv

mv temp.csv date.csv

echo "Fisier sortat dupa numarul de livrari."; sleep 2
rm sortat.csv
