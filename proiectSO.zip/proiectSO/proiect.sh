#!/bin/bash
clear
read -p "Introdu numele fisierului raport: " fisier
if [ -f $fisier ]; then
  clear; ./titlu.sh
  ./meniu.sh

else
touch $fisier
  if ! grep -q "id,nume,livrari,salariu" $fisier; then
    echo "id,nume,livrari,salariu" > $fisier
  fi
nano $fisier
fi
