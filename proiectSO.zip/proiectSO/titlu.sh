#!/bin/bash

coloane=$(tput cols)
linii=$(tput lines)

middle_column=$((coloane/2 - 3))
middle_line=$((linii/2))

tput cup $middle_line $middle_column
printf "\e[1mMENIU\e[0m\n"; sleep 3; clear
